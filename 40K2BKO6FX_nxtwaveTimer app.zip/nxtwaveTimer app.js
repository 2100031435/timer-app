let timer;
let timeLeft = 1500; // 25 minutes in seconds
let isPaused = false;

const display = document.getElementById('display');
const alarm = document.getElementById('alarm');

function updateDisplay() {
    const minutes = Math.floor(timeLeft / 60);
    const seconds = timeLeft % 60;
    display.textContent = `${String(minutes).padStart(2, '0')}:${String(seconds).padStart(2, '0')}`;
}

function startTimer() {
    if (!isPaused) {
        timer = setInterval(() => {
            if (timeLeft > 0) {
                timeLeft--;
                updateDisplay();
            } else {
                clearInterval(timer);
                alarm.play();
                resetTimer();
            }
        }, 1000);
    } else {
        isPaused = false;
    }
}

function pauseTimer() {
    isPaused = true;
    clearInterval(timer);
}

function resetTimer() {
    clearInterval(timer);
    timeLeft = 1500; // Reset to 25 minutes
    isPaused = false;
    updateDisplay();
}

function stopTimer() {
    clearInterval(timer);
    resetTimer();
}

function setTimer(minutes) {
    timeLeft = minutes * 60;
    updateDisplay();
}

document.getElementById('startBtn').addEventListener('click', startTimer);
document.getElementById('pauseBtn').addEventListener('click', pauseTimer);
document.getElementById('resetBtn').addEventListener('click', resetTimer);
document.getElementById('stopBtn').addEventListener('click', stopTimer);
document.getElementById('pomodoroBtn').addEventListener('click', () => setTimer(25));
document.getElementById('shortBreakBtn').addEventListener('click', () => setTimer(5));
document.getElementById('longBreakBtn').addEventListener('click', () => setTimer(15));

updateDisplay();